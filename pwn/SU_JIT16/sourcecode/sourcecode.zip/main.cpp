#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#define MAXINST 0x100
#define MAXCODE 0x1000
using namespace std;
#include "jitinfo.h"
#include <sys/mman.h>

void perr(const char* s){
    cout<<"Error: "<<s<<"\n";
    exit(1);
}

void gen_code(inst* p){
    p->bts=(char*)malloc(MAXSLEN);
    switch(p->opk){
        case OPK_MOV:
            gen_mov(p);
            break;
        case OPK_ADD:
            gen_add(p);
            break;
        case OPK_SUB:
            gen_sub(p);
            break;
        case OPK_LGC:
            gen_lgc(p);
            break;
        case OPK_JMP:
            gen_jmp(p);
            break;
        case OPK_LOD:
            gen_lod(p);
            break;
        case OPK_STO:
            gen_sto(p);
            break;
        case OPK_CRY:
            gen_cry(p);
            break;
        case OPK_HLT:
            gen_hlt(p);
            break;
        default:
            perr("Invalid op!");
    }
}

char rc[4*MAXINST+0x10];

inst* inst_init(int rcins){
    inst* insts=(inst*)malloc(sizeof(inst)*(rcins+2));
    short addr=PREFIXLEN;
    for(int i=0;i<rcins;i++){
        inst* p=insts+i+1;
        int c=*(int*)(rc+i*4);
        p->opk=(c>>OPK_POS)&0xf;
        p->opc=(c>>OPC_POS)&0xf;
        p->dst=(c>>DST_POS)&0xf;
        p->src=(c>>SRC_POS)&0xf;
        p->imm=(c>>IMM_POS)&0xffff;
        //printf("%d %d %d %d %04x\n",p->opk,p->opc,p->dst,p->src,p->imm);
        gen_code(p);
        p->addr=addr;
        addr+=p->len;
    }
    insts[0].addr=0;
    insts[0].len=PREFIXLEN;
    insts[0].bts=prefix;
    insts[rcins+1].addr=addr;
    insts[rcins+1].len=SUFFIXLEN;
    insts[rcins+1].bts=suffix;
    return insts;
}

void verify_jmp(inst* insts,int rcins){
    short addr=PREFIXLEN;
    for(int i=0;i<rcins;i++){
        inst* p=insts+i+1;
        if(p->opk==OPK_JMP){
            if(p->opc==OPC_JMP){
                link_jmp(insts,i,rcins);
            }else if(p->opc==OPC_JE){
                link_je(insts,i,rcins);
            }
        }
        p->addr=addr;
        addr+=p->len;
    }

}

void gen_code_seg(char* buf,inst* insts,int rcins){
    int addr=0;
    for(int i=0;i<=rcins+1;i++){
        memcpy(buf+addr,insts[i].bts,insts[i].len);
        addr+=insts[i].len;
    }
}


int main(){
    setvbuf(stdin, 0LL, 2, 0LL);
    setvbuf(stdout, 0LL, 2, 0LL);
    setvbuf(stderr, 0LL, 2, 0LL);
    cout<<"Welcome to JIT16!\n";
    cout<<"Input ur code:\n";
    int rclen=read(0,rc,4*MAXINST);
    if(rclen%4) perr("Code not aligned!");
    int rcins=rclen/4;

    inst* insts=inst_init(rcins);
    verify_jmp(insts,rcins);
    char* buf=(char*)mmap((void*)NULL,0x1000,PROT_READ|PROT_WRITE,MAP_ANONYMOUS|MAP_PRIVATE,-1,0);
    gen_code_seg(buf,insts,rcins);
    mprotect(buf,0x1000,5);
    char* rwbuf=(char*)mmap((void*)NULL,0x1000,PROT_READ,MAP_ANONYMOUS|MAP_PRIVATE,-1,0);
    cout<<"Sorry, I forget to set the memory region writable...\n";
    int res=((int(*)(char*))buf)(rwbuf);
    cout<<"The return value of your prog is:"<<res<<"\n";
    return 0;
}