from pwn import *
context(arch="amd64",os="linux")

print("""typedef struct{
    char bts[MAXSLEN-1];
    char len;
}x86inst;""")
print("")

def genhex(bt):
    return "".join(["\\x%02x"%(int(i)) for i in bt])

reg=["ax","bx","cx","dx"]

#mrr
print("x86inst mrrc[4][4]={")
for i in reg:
    print("{",end='')
    for j in reg:
        code=f'mov {i},{j}'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")

#mri
print("x86inst mric[4]={",end="")
for i in reg:
    code=f'mov {i},0x1122'
    sc=asm(code)
    print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
print("};")
print("")

#add

print("x86inst addrrc[4][4]={")
for i in reg:
    print("{",end='')
    for j in reg:
        code=f'add {i},{j}'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")

#adc

print("x86inst adcrrc[4][4]={")
for i in reg:
    print("{",end='')
    for j in reg:
        code=f'adc {i},{j}'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")


#sub
print("x86inst subrrc[4][4]={")
for i in reg:
    print("{",end='')
    for j in reg:
        code=f'sub {i},{j}'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")


#sbb
print("x86inst sbbrrc[4][4]={")
for i in reg:
    print("{",end='')
    for j in reg:
        code=f'sbb {i},{j}'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")

##lgc

print("x86inst notc[4]={",end="")
for i in reg:
    code=f'not {i}'
    sc=asm(code)
    print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
print("};")
print("")

print("x86inst negc[4]={",end="")
for i in reg:
    code=f'neg {i}'
    sc=asm(code)
    print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
print("};")
print("")

print("x86inst sgnc[4]={",end="")
for i in reg:
    code=f'shr {i},0xf'
    sc=asm(code)
    print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
print("};")
print("")

print("x86inst tstc[4]={",end="")
for i in reg:
    code=f'test {i},{i}'
    sc=asm(code)
    print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
print("};")
print("")

#jmp

print("x86inst jmpc=",end="")
sc=b"\xeb\x11"
print("{"+f'"{genhex(sc)}",'+str(len(sc))+"};")

print("x86inst jmpfc=",end="")
sc=b"\xe9\x11\x11\x11\x11"
print("{"+f'"{genhex(sc)}",'+str(len(sc))+"};")

print("x86inst jec=",end="")
sc=b"\x74\x11"
print("{"+f'"{genhex(sc)}",'+str(len(sc))+"};")

print("x86inst jefc=",end="")
sc=b"\x0f\x84\x11\x11\x11\x11"
print("{"+f'"{genhex(sc)}",'+str(len(sc))+"};")

#lod
regl=['al','bl','cl','dl']
print("x86inst ldbc[4][4]={")
for dst in regl:
    print("{",end='')
    for src in reg:
        code=f'mov {dst},byte ptr[r8+r{src}]'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")

print("x86inst ldwc[4][4]={")
for dst in reg:
    print("{",end='')
    for src in reg:
        code=f'mov {dst},word ptr[r8+r{src}]'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")


#sto
print("x86inst stbc[4][4]={")
for dst in reg:
    print("{",end='')
    for src in regl:
        code=f'mov byte ptr[r8+r{dst}],{src}'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")

print("x86inst stwc[4][4]={")
for dst in reg:
    print("{",end='')
    for src in reg:
        code=f'mov word ptr[r8+r{dst}],{src}'
        sc=asm(code)
        print("{"+f'"{genhex(sc)}",'+str(len(sc))+"},",end="")
    
    print("},")

print("};")
print("")

#cry
print("x86inst stcc=",end="")
sc=asm("stc")
print("{"+f'"{genhex(sc)}",'+str(len(sc))+"};")

print("x86inst clcc=",end="")
sc=asm("clc")
print("{"+f'"{genhex(sc)}",'+str(len(sc))+"};")

#hlt()
print("x86inst hltc=",end="")
sc=asm("hlt")
print("{"+f'"{genhex(sc)}",'+str(len(sc))+"};")

print("\nchar prefix[0x100]=\"",end="")
code='''
    mov r8,rdi
    xor rax,rax
    xor rbx,rbx
    xor rcx,rcx
    xor rdx,rdx
    xor rdi,rdi
    xor rsi,rsi
    xor r9,r9
    xor r10,r10
    xor r11,r11
    xor r12,r12
    xor r13,r13
    xor r14,r14
    xor r15,r15
'''
sc=asm(code)
print(genhex(sc)+"\";")
print(f"#define PREFIXLEN {len(sc)}")

print("\nchar suffix[0x100]=\"",end="")
code='''
    ret
'''
sc=asm(code)
print(genhex(sc)+"\";")
print(f"#define SUFFIXLEN {len(sc)}\n")