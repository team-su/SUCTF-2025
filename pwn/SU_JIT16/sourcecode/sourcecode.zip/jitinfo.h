#define IMM_POS 0x10
#define OPK_POS 0x4
#define OPC_POS 0x0
#define DST_POS 0xc
#define SRC_POS 0x8
#define MAXSLEN 0x10

#define OPK_MOV 0
#define OPK_ADD 1
#define OPK_SUB 2
#define OPK_LGC 4
#define OPK_JMP 5
#define OPK_LOD 6
#define OPK_STO 7
#define OPK_CRY 8
#define OPK_HLT 9

#define MAXREG 4
#define REG_AX 0
#define REG_BX 1
#define REG_CX 2
#define REG_DX 3
extern void perr(const char* s);
#include <string.h>
#include "x86code.h"

typedef struct{
    char opk;
    char opc;
    char dst;
    char src;
    short imm;
    char len;
    int addr;
    char* bts;
}inst;



#define OPC_MRR 0
#define OPC_MRI 1

void gen_mov(inst* p){
    char s=p->src;
    char d=p->dst;
    if(p->opc==OPC_MRR){
        if(p->src>=MAXREG || p->dst>=MAXREG){
            perr("Invalid REG!");
        }
        memcpy(p->bts,mrrc[d][s].bts,mrrc[d][s].len);
        p->len=mrrc[d][s].len;
    }else if(p->opc==OPC_MRI){
        if(p->dst>=MAXREG){
            perr("Invalid REG!");
        }
        memcpy(p->bts,mric[d].bts,mric[d].len);
        *(short*)(p->bts+2)=p->imm;
        p->len=mric[d].len;
    }else{
        perr("Invalid OP!");
    }
}

#define OPC_ADD 0
#define OPC_ADC 1

void gen_add(inst *p){
    char s=p->src;
    char d=p->dst;
    if(p->opc==OPC_ADD){
        if(p->src>=MAXREG || p->dst>=MAXREG){
            perr("Invalid REG!");
        }
        memcpy(p->bts,addrrc[d][s].bts,addrrc[d][s].len);
        p->len=addrrc[d][s].len;
    }else if(p->opc==OPC_ADC){
        if(p->src>=MAXREG || p->dst>=MAXREG){
            perr("Invalid REG!");
        }
        memcpy(p->bts,adcrrc[d][s].bts,adcrrc[d][s].len);
        p->len=adcrrc[d][s].len;
    }else{
        perr("Invalid OP!");
    }
}

#define OPC_SUB 0
#define OPC_SBB 1

void gen_sub(inst *p){
    char s=p->src;
    char d=p->dst;
    if(p->opc==OPC_SUB){
        if(p->src>=MAXREG || p->dst>=MAXREG){
            perr("Invalid REG!");
        }
        memcpy(p->bts,subrrc[d][s].bts,subrrc[d][s].len);
        p->len=subrrc[d][s].len;
    }else if(p->opc==OPC_SBB){
        if(p->src>=MAXREG || p->dst>=MAXREG){
            perr("Invalid REG!");
        }
        memcpy(p->bts,sbbrrc[d][s].bts,subrrc[d][s].len);
        p->len=subrrc[d][s].len;
    }else{
        perr("Invalid OP!");
    }
}

#define OPC_NOT 0
#define OPC_NEG 1
#define OPC_SGN 2
#define OPC_TST 4

void gen_lgc(inst* p){
    char s=p->src;
    if(s>MAXREG){
        perr("Invalid REG!");
    }
    if(p->opc==OPC_NOT){
        memcpy(p->bts,notc[s].bts,notc[s].len);
        p->len=notc[s].len;
    }else if(p->opc==OPC_NEG){
        memcpy(p->bts,negc[s].bts,negc[s].len);
        p->len=negc[s].len;
    }else if(p->opc==OPC_SGN){
        memcpy(p->bts,sgnc[s].bts,sgnc[s].len);
        p->len=sgnc[s].len;
    }else if(p->opc==OPC_TST){
        memcpy(p->bts,tstc[s].bts,tstc[s].len);
        p->len=tstc[s].len;
    }
    else{
        perr("Invalid OP!");
    }
}

#define OPC_JMP 0
#define OPC_JE 1

void gen_jmp(inst* p){
    if(p->opc==OPC_NOT){
        memcpy(p->bts,jmpc.bts,jmpc.len);
        p->len=jmpc.len;
    }else if(p->opc==OPC_NEG){
        memcpy(p->bts,jec.bts,jec.len);
        p->len=jec.len;
    }
    else{
        perr("Invalid OP!");
    }
}

#define OPC_LDB 0
#define OPC_LDW 1

void gen_lod(inst* p){
    char s=p->src;
    char d=p->dst;
    if(p->opc==OPC_LDB){
        memcpy(p->bts,ldbc[d][s].bts,ldbc[d][s].len);
        p->len=ldbc[d][s].len;
    }else if(p->opc==OPC_LDW){
        memcpy(p->bts,ldwc[d][s].bts,ldwc[d][s].len);
        p->len=ldwc[d][s].len;
    }else{
        perr("Invalid OP!");
    }
}

#define OPC_STB 0
#define OPC_STW 1

void gen_sto(inst* p){
    char s=p->src;
    char d=p->dst;
    if(p->opc==OPC_STB){
        memcpy(p->bts,stbc[d][s].bts,stbc[d][s].len);
        p->len=stbc[d][s].len;
    }else if(p->opc==OPC_STW){
        memcpy(p->bts,stwc[d][s].bts,stwc[d][s].len);
        p->len=stwc[d][s].len;
    }else{
        perr("Invalid OP!");
    }
}

#define OPC_STC 0
#define OPC_CLC 1


void gen_cry(inst* p){
    if(p->opc==OPC_STC){
        memcpy(p->bts,stcc.bts,stcc.len);
        p->len=stcc.len;
    }else if(p->opc==OPC_CLC){
        memcpy(p->bts,clcc.bts,clcc.len);
        p->len=clcc.len;
    }
    else{
        perr("Invalid OP!");
    }
}

#define OPC_BAK 0

void gen_hlt(inst* p){
    if(p->opc==OPC_STC){
        memcpy(p->bts,hltc.bts,hltc.len);
        p->len=hltc.len;
    }
    else{
        perr("Invalid OP!");
    }
}

void link_jmp(inst* insts,int idx,int rcins){
    inst* p=insts+idx+1;
    int didx=idx+p->imm+1;
    if(didx<0 || didx>rcins){
        perr("Invalid jmp dst!");
    }
    inst* d=p+p->imm+1;
    int joff=d->addr-(p->addr+p->len);
    if(joff>0x7f || joff<-0x80){
        memcpy(p->bts,jmpfc.bts,jmpfc.len);
        p->len=jmpfc.len;
        if(p->imm<0) joff=d->addr-(p->addr+p->len);
        *(int*)(p->bts+1)=joff;
    }
    else{
        p->bts[1]=(char)joff;
    }
}
void link_je(inst* insts,int idx,int rcins){
    inst* p=insts+idx+1;
    int didx=idx+p->imm+1;
    if(didx<0 || didx>rcins){
        perr("Invalid jmp dst!");
    }
    inst* d=p+p->imm+1;
    int joff=d->addr-(p->addr+p->len);
    if(joff>0x7f || joff<-0x80){
        memcpy(p->bts,jefc.bts,jefc.len);
        p->len=jefc.len;
        if(p->imm<0) joff=d->addr-(p->addr+p->len);
        *(int*)(p->bts+2)=joff;
    }
    else{
        p->bts[1]=(char)joff;
    }
}